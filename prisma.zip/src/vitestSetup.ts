import { faker } from '@faker-js/faker'

faker.seed(11) // this makes sure every run we get the same values from faker, which is nice to have for snapshots
